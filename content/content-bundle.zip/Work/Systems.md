Here is a list of current systems I am learning or working on:

- **Salesforce**
	- Integrating Salesforce as a CRM for a small company
	- Also integrating Conga as our Contract Management solution
- **SharePoint**
	- Created a company wide intranet and implemented Yammer/Viva for our watercooler chats
	- Also learning how to develop websites for external clients too
- **Google Workspace**
	- Admin for the workforce Google Workspace accounts.
		- Email
		- Drive
		- Chat
- **Microsoft 365**
	- Utilizing this in a minimal way. Office Suite of products and SharePoint (see above)