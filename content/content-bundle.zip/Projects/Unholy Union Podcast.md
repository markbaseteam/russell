# Summary

Here's another one of our side projects! It's a delightful hobby my wife and I indulge in together. We engage in conversations about contemporary events, important issues, and we even have the pleasure of interviewing everyday individuals who are working hard and making positive contributions to the world.

# Equipment

**Rodecaster Pro** https://rode.com/en-us/interfaces-and-mixers/rodecaster-series/rodecaster-pro

**Rode Podmics qty. 2** https://rode.com/en-us/microphones/broadcast/podmic

**Mackie MC-100 qty. 2** https://mackie.com/en/products/headphones/mc-series-headphones/MC_100.html

# Software

**Descript** https://www.descript.com/
	I use this to edit the podcast. It allows you to edit the audio via a transcript and saves me a ton of time removing unnecessary ums and ahs.

**Auphonic** https://auphonic.com/
	An amazing audio polisher. This program levels out audio, removes background noises, and equalizes our voices to sound more pleasant to the ear.

**Podpage** https://www.podpage.com/
	An amazing podcast webpage builder. Has everything you could ever want for a website that is designed for podcasters.

**Spreaker** https://spreaker.com
	This is our current host. We chose Spreaker because it is free and I would prefer to spend the money on ensuring the audio quality and listener experience is top tier.

**Headliner** https://headliner.app
	This app automatically creates YouTube videos and auto posts them for us. Saves me a lot of time on the backend and one less thing to worry about. Their generous free plan allows us to post weekly podcast episodes with no watermarks. 

# Websites

https://www.unholyunionpodcast.com
https://store.unholyunionpodcast.com
https://twitter.com/unholyunioncast
https://www.facebook.com/unholyunionpodcast
https://www.instagram.com/unholyunioncast/
https://youtube.com/@unholyunionpod/