I established "The Mind of Russ" as a means to chronicle my personal journey dealing with OCD and anxiety. I generate income from this endeavor using Substack, primarily as a donation platform to support my writing. My intention has never been to restrict access to any of the content I share; contributing financially will always remain optional.

I personally found solace in connecting with others who have experienced similar challenges, and my goal is to ensure that I can offer assistance to anyone grappling with mental illness in any way possible.

https://themindofruss.substack.com