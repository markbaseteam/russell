Obsessive-compulsive disorder (OCD) is a mental health disorder that involves unwanted and intrusive thoughts (obsessions) and repetitive behaviors (compulsions). People with OCD may feel the need to perform these compulsions to try to relieve the anxiety caused by the obsessions.

Some common obsessions include:

- Fear of contamination
- Doubting
- Need for symmetry or order
- Aggressive or violent thoughts
- Sexual thoughts
- Harming oneself or others

Some common compulsions include:

- Washing or cleaning
- Checking things repeatedly
- Counting
- Arranging things in a specific order
- Hoarding
- Asking for reassurance

OCD can be a very debilitating disorder, and it can interfere with a person's daily life, work, and relationships. However, there are effective treatments available, including psychotherapy and medication.

If you think you or someone you know may have OCD, it is important to seek professional help. With treatment, most people with OCD can learn to manage their symptoms and live a full and productive life.

Here are some additional information about OCD:

- OCD is a relatively common disorder, affecting about 1% of the population.
- OCD can occur at any age, but it usually starts in early adulthood.
- The exact cause of OCD is unknown, but it is thought to be caused by a combination of genetic and environmental factors.
- There is no cure for OCD, but it can be managed with treatment.
- The most effective treatments for OCD are psychotherapy and medication.
- Psychotherapy can help people with OCD to understand their disorder and develop coping mechanisms.
- Medication can help to reduce the symptoms of OCD, such as anxiety and depression.

There are multiple [[OCD Resources|resources]] that helped me through the thick of things.