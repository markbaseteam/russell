- https://drmichaeljgreenberg.com/ 
	Dr. Greenberg helped me immensely when I was at my lowest point with OCD. I had already completed a round of ERP therapy with another therapist, but I still felt like I could be doing better. That's when I contacted Dr. Greenberg's OCD Associates.
	
	Their methods are different from other ERP practitioners in that they focus more on response prevention than habituating the feelings towards the thoughts. This was a game-changer for me, as I knew that I would never be okay with thinking these violent thoughts. Dr. Greenberg and his team helped me to overcome the 70% better hump and reach a 95-100% recovery rate. They literally changed my life.
	
	Here are some specific examples of how Dr. Greenberg's methods helped me:
	
	- They taught me how to identify and challenge my compulsions. For example, I used to check the locks on my door multiple times before going to bed. Dr. Greenberg helped me to understand that this was a compulsion, and that it was actually making my anxiety worse.
	- They helped me to develop a tolerance for anxiety. This was difficult at first, but it was essential for me to overcome my OCD. Dr. Greenberg taught me how to sit with my anxiety and not try to push it away.
	- They helped me to understand the root of my OCD. My OCD was triggered by a traumatic event in my past. Dr. Greenberg helped me to process this trauma and to develop healthier coping mechanisms.
	  
	I am so grateful to Dr. Greenberg and his team for their help. They truly changed my life. If you are struggling with OCD, I highly recommend reaching out to them.
---
- https://www.psychologytoday.com/us/therapists/suzie-long-fort-lauderdale-fl/784578
	Dr. Suzie Long is an amazing and caring therapist who I used from Dr. Greenberg's OCD Associates. She kept in close contact with me throughout my entire treatment, and she always responded to my emails promptly.
	
	Here are some specific examples of how Dr. Long was helpful to me:
	
	- She was very understanding and patient with me. I was often anxious and overwhelmed, but she always took the time to listen to me and to help me to feel calm.
	- She was very knowledgeable about OCD and its treatment. She was able to explain my symptoms to me in a way that I could understand, and she helped me to develop a treatment plan that was tailored to my needs.
	- She was very supportive and encouraging. She never gave up on me, even when I felt like I wanted to give up. She helped me to stay motivated and to keep working towards my goals.
---
- https://iocdf.org/
	The IOCDF (International Obsessive Compulsive Disorder Foundation) was where I found my first ERP therapist. Surprisingly, therapists that are specializing in ERP are pretty hard to find. This website also keeps you up to date with news, articles, and even success stories from fellow sufferers.