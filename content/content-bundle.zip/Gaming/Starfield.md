I found Starfield to be an enjoyable game. The graphics are stunning, presenting space in a visually impressive manner. The HUD is exceptional, providing necessary information while maintaining a minimalistic design. Additionally, the game runs smoothly on my PC. However, despite these positive aspects, there are some drawbacks that prevent it from surpassing BG3 as my Game of the Year.

## Gameplay

This is where Starfield truly shines. Bethesda games have often been plagued by bugs upon release, and the shooting mechanics in the Fallout series left much to be desired. Personally, I was never a fan of the shooting in Fallout, but the captivating story and other elements of the game kept me engaged. Starfield, on the other hand, significantly improves the shooting mechanics. The game feels responsive, and the gun designs are impressive. While it still falls short of the shooting mechanics found in games like Destiny or Borderlands, the improvements are substantial enough that I am enjoying this aspect of the gameplay.

Remarkably, Starfield is the least buggy game Bethesda has released. I encountered only one bug that required me to load a saved game and regain my progress. Fortunately, this setback only cost me about 5-10 minutes of gameplay. I won't divulge the cause of the bug to avoid spoilers. My suggestion would be to save your progress as frequently as possible.

However, the exploration aspect of the game is somewhat lacking. Admittedly, this disappointment may be partly my fault, as No Man's Sky has spoiled me with its ability to seamlessly transition from planet to space and then to another planet within the same system. The feeling of venturing into uncharted territory as you pilot your ship and break through the atmosphere of a new planet is exhilarating. Unfortunately, Starfield does not offer this style of exploration. You cannot fly from space to the surface of a planet. A gaming journalist attempted this and it took them 7 hours, only to clip through the planet upon arrival. The exploration in Starfield feels like filler content that adds very little to the overall game.

## Graphics

Starfield boasts impressive visuals. Space looks outstanding, with its abundance of asteroids and space stations. The weapon and character models are well-crafted. Strangely enough, one of my favorite aspects of the game's presentation is the HUD. It is simplistic yet provides all the necessary information about your character.

## Story

This is where my feelings become conflicted. I found the story in Starfield to be lacking, and I suspect that Baldur's Gate 3 has spoiled me in this regard. While Starfield offers numerous choices, none of them seem to have a significant impact. Some choices may slightly alter the story, but they ultimately feel inconsequential. If you are seeking an RPG where your choices genuinely influence the story and your progression, I recommend trying Baldur's Gate 3. In that game, your decisions truly matter.

In conclusion, Starfield is a good but not great game. Prior to its release, it was my most anticipated game of 2023. However, after playing it and completing the story, I realized that I may have set unrealistic expectations. While the shooting mechanics have improved, the story is only average, and the impact of your decisions is minimal. Nonetheless, I still enjoy Starfield and would recommend it to fans of Bethesda's other games.