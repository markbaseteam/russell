I'm a pretty big fan of MMOs and have been for a long time. But over the past 10 years or so, it seems like their quality has really gone downhill. And that bums me out since I love these kinds of games so much. I mean, World of Warcraft is still around, but I'm getting tired of playing the same old game again and again. I'm craving something fresh! 

That's where New World and its new expansion Rise of Angry Earth come in. When Amazon first announced New World as a free-to-play game, I pre-ordered it right away. And even though they later changed it to buy-to-play, Amazon still honored my pre-order and gave me a free copy, which was awesome. I tried playing New World when it first launched but honestly, it was kind of a glitchy mess at the time, so I stopped.  

But with this new expansion out, I decided to give it another shot. And so far, I'm really liking the change of pace from the usual tab-target combat in games like WoW. In New World, you have to actively aim and time your attacks. And  being able to equip different weapon types and mix up your abilities is pretty cool too. It adds a fun new dynamic to combat.

One thing I'm surprisingly enjoying is all the gathering you can do - like chopping down trees. I don't know why, but there's something relaxing and satisfying about it. 

The new mounts and the flail weapon are probably my favorite additions from the expansion. It's nice to finally be able to ride around on horses rather than hoof it everywhere. And the flail is a sweet new weapon that combines magic and melee attacks while also letting you buff yourself and allies. Feels good to smash things with it!

So yeah, I'm feeling New World at the moment but not sure if I'll stay hooked long-term. I love MMOs but nothing has really wowed me in years. Hopefully some new and exciting games come along soon to breathe new life into the genre and break up the monotony. But for now, New World is scratching my MMO itch.   